/* eslint-disable react/jsx-no-undef */
// eslint-disable-next-line no-unused-vars
import React, { useState } from 'react'
import  Navbar from './Componets/Navbar/Navbar'
import Home from './Componets/Home/Home'
import SignInModal from './Componets/SignInModal/SignInModal';




const App = () => {

  const [modalIsOpen, setModalIsOpen] = useState(false);

  return (
   

    <div className='app'>
      <Navbar setShowLogin={setModalIsOpen} />
      <Home />
      <SignInModal modalIsOpen={modalIsOpen} setModalIsOpen={setModalIsOpen} />
      
     
      
    </div>

    
  )
}

export default App
