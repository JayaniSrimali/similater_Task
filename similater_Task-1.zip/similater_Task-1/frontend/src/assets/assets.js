// eslint-disable-next-line no-unused-vars
import logo from './logo.png'
import Home1 from './Home1.jpeg'
import Home2 from './Home2.jpeg'
import Home3 from './Home3.jpeg'
import Home4 from './Home4.jpeg'
import Home5 from './Home5.jpeg'
import Home6 from './Home6.jpeg'
import Home7 from './Home7.jpeg'
import footer1 from './footer1.png'
import footer2 from './footer2.png'
import footer3 from './footer3.png'
import footer4 from './footer4.png'
import footer5 from './footer5.png'
import footer6 from './footer6.png'
import bath_icon from './bath_icon.png'
import person_outline from './person-outline.png'
import key from './key.png'
import home_outline from './home-outline.png'




export const assets = {
    logo,
    Home1,
    Home2,
    Home3,
    Home4,
    Home5,
    Home6,
    Home7,
    footer1,
    footer2,
    footer3,
    footer4,
    footer5,
    footer6,
    bath_icon,
    person_outline,
    key,
    home_outline,
    
    


}