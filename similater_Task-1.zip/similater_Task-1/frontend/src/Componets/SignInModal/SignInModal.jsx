// eslint-disable-next-line no-unused-vars
import React from 'react';
import Modal from 'react-modal';
import './SignInModal.css'

// eslint-disable-next-line react/prop-types
const SignInModal = ({ modalIsOpen, setModalIsOpen }) => {

  const closeModal = () => setModalIsOpen(false);

  return (
    <Modal
      isOpen={modalIsOpen}
      onRequestClose={closeModal}
      contentLabel="Sign In Modal"
      className="modal"
      overlayClassName="overlay"
    >
      <button className="close-button" onClick={closeModal}>×</button>
      <h2>Sign In</h2>
      <p>welcome back</p>
      <form>
        <div className="form-group">
          <input type="email" placeholder="Email Address" />
        </div>
        <div className="form-group">
          <input type="password" placeholder="Password" />
        </div>
        <div className="form-options">
          <div className="checkbox-group">
            <input type="checkbox" id="show-password" />
            <label htmlFor="show-password">Show Password</label>
          </div>
          <a href="/forgot-password">Lost Your Password?</a>
        </div>
        <button type="submit" className="login-button">Login</button>
      </form>
    </Modal>
  );
};

export default SignInModal;
