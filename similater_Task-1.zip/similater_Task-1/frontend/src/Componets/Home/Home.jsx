// eslint-disable-next-line no-unused-vars
import React from 'react';
import './Home.css';
import { assets } from '../../assets/assets';

const Home = () => {
  return (
    <div className="home-container">
      <main className="content">
        <div className="left-panel">
          <div className="main-image">
            <img src={assets.Home1} alt="Main Apartment" />
          </div>
          <div className="property-details">
            <p>Apartments in 123 Dolorum architecto, B1 1GB</p>
            <h2>Lorem ipsum dolor</h2>
            <p>
              <img src={assets.home_outline} alt="home_outline" className='home_outline' />
              2 Bedrooms
              <img src={assets.bath_icon} alt="bath_icon" className='bath_icon' />
              2 Bathrooms
              <img src={assets.person_outline} alt="person_icon " className='person_icon' />
              5 Guests
            </p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec at rutrum sapien, a volutpat massa. Maecenas congue luctus dui quis rhoncus. Praesent feugiat nulla quis libero tristique tempor. Vivamus efficitur rhoncus neque id lacinia. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>




            
            <ul>
              <li><h3> Designed for Quality</h3></li>
              <li> <img src={assets.key} alt="key " className='key' /> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
              <li> <img src={assets.key} alt="key " className='key' /> In quis urna pretium, pretium mi sit amet, pellentesque enim.</li>
              <li> <img src={assets.key} alt="key " className='key' /> Sed sagittis nulla non congue lacinia.</li>
              <li> <img src={assets.key} alt="key " className='key' /> Vivamus non sapien id purus ultricies cursus eu eu felis.</li>
            </ul>
          </div>
        </div>
        <div className="right-panel">
          <div className="sub-images">
            <img src={assets.Home2} alt="Sub Image 1" />
            <img src={assets.Home3} alt="Sub Image 2" />
            <img src={assets.Home4} alt="Sub Image 3" />
            <img src={assets.Home5} alt="Sub Image 4" />
            <img src={assets.Home7} alt="Sub Image 5" />
            <img src={assets.Home6} alt="Sub Image 6" />
          </div>

          <div className="reservation-form">
      <h3>Make a reservation</h3>
      <div className="form-row">
        <input type="text" placeholder="Move-in" />
        <input type="text" placeholder="Move-out" />
      </div>
      <div className="form-row">
        <input type="text" placeholder="First Name" />
        <input type="text" placeholder="Last Name" />
      </div>
      <div className="form-row">
        <input type="email" placeholder="Email Address" />
        <input type="tel" placeholder="Mobile Number" />
      </div>
      <button className="book-button">Book Now</button>
    </div>
        </div>
      </main>

      <footer className="footer">
        <div className="footer-left">
          <img src={assets.logo} alt="Logo" className="logo" />
          <p>© 2024 Similater (Pvt) Ltd. All rights reserved.</p>
        </div>
        <div className="footer-right">
          <div className="payment-icons">
            <img src={assets.footer1} alt="Amex" />
            <img src={assets.footer2} alt="Pay" />
            <img src={assets.footer3} alt="Stripe" />
            <img src={assets.footer4} alt="Pay2" />
            <img src={assets.footer5} alt="Mastercard" />
            <img src={assets.footer6} alt="Visa" />
          </div>
          <p className="footer-text">Neque porro quisquam est qui dolorem ipsum</p>
        </div>
      </footer>
    </div>
  );
}

export default Home;
