// eslint-disable-next-line no-unused-vars
import React, { useState } from 'react';
import './Navbar.css';
import { assets } from '../../assets/assets';

// eslint-disable-next-line react/prop-types
const Navbar = ({ setShowLogin }) => {
  const [Menu, setMenu] = useState("Home");

  return (
    <div className='navbar'>
      <img src={assets.logo} alt="" className="logo" />
      <ul className="navbar-menu">
        <li onClick={() => setMenu("Locations")} className={Menu === "Locations" ? "active" : ""}>Locations</li>
        <li onClick={() => setMenu("Standards")} className={Menu === "Standards" ? "active" : ""}>Standards</li>
        <li onClick={() => setMenu("About")} className={Menu === "About" ? "active" : ""}>About</li>
        <li onClick={() => setMenu("Contact")} className={Menu === "Contact" ? "active" : ""}>Contact</li>
      </ul>
      <div className="navbar-right">
        <button onClick={() => setShowLogin(true)}>Login</button>
      </div>
    </div>
  );
}

export default Navbar;
